"""پنجره‌های UI (MainWindow و ...)."""

