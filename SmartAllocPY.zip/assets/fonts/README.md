Place Persian font files here for best UI/PDF rendering.

Recommended files:
- Vazir.ttf (or Vazir-Regular.ttf)
- B-Nazanin.ttf
- Tahoma.ttf (fallback)

This repository does not include font binaries. Download from official sources:
- Vazir: https://rastikerdar.github.io/vazir-font/
- B Nazanin: licensed fonts — ensure you have redistribution rights.

The app will gracefully fall back to system fonts if these are missing.

