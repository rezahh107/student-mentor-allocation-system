#!/bin/bash
export PYTHONPATH="$(pwd)"
echo "Environment activated. PYTHONPATH set to $(pwd)"
