"""هسته UI: State، EventBus، Theme."""

