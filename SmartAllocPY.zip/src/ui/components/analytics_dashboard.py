﻿from ..widgets.analytics_dashboard import AnalyticsDashboard  # noqa: F401
